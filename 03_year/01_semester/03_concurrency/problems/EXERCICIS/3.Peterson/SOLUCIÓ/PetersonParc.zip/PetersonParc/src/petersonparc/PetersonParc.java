/*
  Exercici 3 - Simulació d'entrades a un parc 
 */
package petersonparc;

/**
 *
 * @author Juan Mesquida Arenas i Jogil Moreno Martínez
 * 
 */
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class PetersonParc implements Runnable {

    //variables temps
    static double tempsMig0 = 0;
    static double tempsMig1 = 0;
    static double tempsPrevi0 = 0;
    static double tempsPrevi1 = 0;
    //variables Peterson
    static final int THREADS = 2;//2 portes distintes
    static final int MAX_COUNT = 20; //10 pics per cada thread
    static volatile int[] want = new int[THREADS];
    static volatile int last = 0;
    static volatile int n = 0;
    int id;
    static int[] porta = new int[THREADS]; //núm d'entrades a cada porta
/**
 * Métode constructor
 * @param id indica quina porta es
 */
    public PetersonParc(int id) {
        this.id = id;
    }

    @Override
    public void run() {
        int max = MAX_COUNT / THREADS;//10 entrades per 1 porta
        int altreProces = (id + 1) % THREADS;
        System.out.println("Entrada " + id);

        for (int i = 0; i < max; i++) {
            /*
             * IMPORTANT QUE SLEEP ES FACI ABANS D'ENTRAR A LA SECCIÓ CRÍTICA*
             * SINO APAREIXEN SOLUCIONS SEQUENCIALS I NO PODEM APRECIAR DE
             * MANERA CORRECTA LA SOLUCIÓ AMB CONCURRENCIA
             */
            Random r = new Random();
            int sleep = r.nextInt(5000) + 1; //retard entre 1 y 5000 
            try {
                Thread.sleep(sleep);//retard seccio critica
            } catch (InterruptedException ex) {
                System.out.println("Error: " + ex.getMessage());
            }
            //Peterson
            want[id] = 1;
            last = id;
            //espera fins que l'altre procès acabi
            while (want[altreProces] == 1 && last == id) {
            }

            //moment on s'entra a la seccio critica(porta)
            DateFormat df = new SimpleDateFormat("HH:mm:ss:SSS");
            Date date = new Date(System.currentTimeMillis());
            //milisegons
            double datamilisec = date.getTime();

            //sumam 1 cada vegada que entram dins la seccio critica(porta)
            porta[id]++;

            //obtenim temps totals de cada porta
            if (i != 0) {
                if (id == 0) {
                    tempsMig0 = tempsMig0 + (datamilisec - tempsPrevi0);
                } else {
                    tempsMig1 = tempsMig1 + (datamilisec - tempsPrevi1);
                }
            }
            //obtenim temps previ 
            if (id == 0) {
                tempsPrevi0 = datamilisec;
            } else {
                tempsPrevi1 = datamilisec;
            }

            System.out.println("Porta " + id + ": " + porta[id]
                    + " entrades de : " + (n + 1) + " Temps: " + df.format(date));

            n += 1; //SC
            want[id] = 0;
        }
    }
/**
 * MÈTODE MAIN
 * @param args
 * @throws InterruptedException 
 */
    public static void main(String[] args) throws InterruptedException {
        Thread[] threads = new Thread[THREADS];
        want[0] = 0;
        want[1] = 0;

        int i;
        //inicialitzam threads
        for (i = 0; i < THREADS; i++) {
            threads[i] = new Thread(new PetersonParc(i));
            threads[i].start();
        }
        //esperam a que acabin els threads
        for (i = 0; i < THREADS; i++) {
            threads[i].join();
        }

        //Calculam el temps mig de les 2 portes
        //els pasam a milisegons dividint entre 1000
        tempsMig0 = (tempsMig0 / (MAX_COUNT / THREADS)) / 1000;
        tempsMig1 = (tempsMig1 / (MAX_COUNT / THREADS)) / 1000;

        //imprimim temps i total entrades per pantalla
        System.out.println("Entrades totals: " + n);
        System.out.println("Temps mig porta 0: " + tempsMig0 + " segons");
        System.out.println("Temps mig porta 1: " + tempsMig1 + " segons");

    }
}
