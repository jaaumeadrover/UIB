import threading

THREADS = 2

want0 = False
want1 = False

class DekkersAlgorithm():

    def thread0(self):
        tid = 0
        global turno
        global sumatori
        while want1 == False:
            want0 = True
        print("process 1 running in critical section")
        want0 = False


    def thread1(self):
        tid = 1
        global turno
        global sumatori
        while want0 == False:
            want1 = True
        print("process 2 running in critical section")
        want1 = False



    def main(self):
        while True:
            t1 = threading.Thread(target = self.thread0) 
            t1.start()
            t2 = threading.Thread(target = self.thread1) 
            t2.start()

if __name__ == "__main__":
    d = DekkersAlgorithm()
    d.main()
