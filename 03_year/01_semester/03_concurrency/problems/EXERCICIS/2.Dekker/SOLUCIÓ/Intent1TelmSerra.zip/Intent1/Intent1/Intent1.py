import threading
import time
THREADS = 2
sumatori = 0
turno = 0
MAXCOUNT = 100
class DekkersAlgorithm():

    def thread0(self):
        tid = 0
        localSumatori = 0
        global turno
        global sumatori
        global MAXCOUNT
        while localSumatori < MAXCOUNT:
            while tid != turno:
                pass
            #---Zona Critica---
            sumatori += 1
            localSumatori +=1
            #---Sortida Zona Critica---
            turno = 1
        print("Thread " + str(tid) + " finalitzat")

    def thread1(self):
        tid = 1
        localSumatori = 0
        global turno
        global sumatori
        while localSumatori < MAXCOUNT:
            while tid != turno:
                pass
            #Zona critica
            sumatori += 1 
            localSumatori +=1
            #---Sortida Zona Critica---
            #En el cas de que un dels threads finalitzes i l'altre quedaria en espera infinita ja que cap thread li cediria el torn
            turno = 0
        print("Thread " + str(tid) + " finalitzat")



    def main(self):
        global sumatori
        global MAXCOUNT
        #Creació dels dos threads
        t1 = threading.Thread(target = self.thread0) 
        t1.start()
        t2 = threading.Thread(target = self.thread1) 
        t2.start()
        t1.join();
        t2.join()
        print("Esperants: " + str(MAXCOUNT*2) + " Rebuts: " + str(sumatori) )
        #t3 = threading.Thread(target = self.thread2) 
        #t3.start()


if __name__ == "__main__":
    d = DekkersAlgorithm()
    d.main()
