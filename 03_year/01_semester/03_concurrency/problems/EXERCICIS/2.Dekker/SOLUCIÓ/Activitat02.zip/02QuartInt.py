import threading
import time

THREADS = 2
MAX = 100000
count = 0
wantp = False
wantq = False
comptador = 0

def thread1():
    global wantq
    global wantp
    global comptador
    global count
    #bucle principal
    for i in range(MAX):
        #solicita entrada
        wantp = True
        #espera activa
        while  wantq:
            wantp = False
            wantp = True
            comptador += 1
        #regio critica
        count += 1
        wantp = False
    print("Hi, I'm the thread {}".format(threading.current_thread().name) +
          "and i have finished \n" )
    
    
    
def thread2():
    global wantp
    global wantq        
    global count   
    #bucle principal
    for i in range(MAX):
        #solicitam entrada
        wantq = True
        #espera activa
        while  wantp:
            wantq = False
            wantq = True
        #regio critica
        count += 1
        wantq = False
    print("Hi, I'm the thread {}".format(threading.current_thread().name) +
          "and i have finished \n" )
   
    
    
def main():
    threads = []

    global comptador
    # Create new threads
    t = threading.Thread(target=thread1)
    threads.append(t)
    t.start() # start the thread
    t = threading.Thread(target=thread2)
    threads.append(t)
    t.start() # start the thread
    

    # Wait for all threads to complete
    for t in threads:
        t.join()
    print("--- %s seconds ---" % (time.time() - start_time))
    print("End")
    print(count)
    print("Contador d'iteracions al bucle d'espera: %s" % comptador)
    #amb aquest comptador veim quantes iteracions fa a l'espera activa
    #la concurrencia de python es veu questionada
if __name__ == "__main__":
    start_time = time.time()
    main()
