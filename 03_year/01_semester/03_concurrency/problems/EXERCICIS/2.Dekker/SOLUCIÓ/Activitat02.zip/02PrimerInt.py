import threading
import time

THREADS = 2
MAX = 100
count = 0
TURN = 1
contador1 = 0
contador2 = 0

def thread1():
    global count
    global TURN
    global contador1
    
    #bucle principal
    for i in range(MAX):    
        while (TURN != 1):
            pass
            contador1 += 1
        #regio critica
        count += 1
        TURN = 2
    print("Hi, I'm the thread {}".format(threading.current_thread().name) +
          "and i have finished \n" )
    
    
    
def thread2():
    global TURN
    global count
    global contador2
    
   #regio no critica
    time.sleep(5)
    
    #bucle principal
    for i in range(MAX):
        
        while (TURN != 2):
            pass
            contador2 += 1
        #regio critica
        count += 1
        TURN = 1
    print("Hi, I'm the thread {}".format(threading.current_thread().name) +
          "and i have finished \n")
    
    
def main():
    threads = []

   
    # Create new threads
    t = threading.Thread(target=thread1)
    threads.append(t)
    t.start() # start the thread
    t = threading.Thread(target=thread2)
    threads.append(t)
    t.start() # start the thread
    

    # Wait for all threads to complete
    for t in threads:
        t.join()
    print("--- %s seconds ---" % (time.time() - start_time))
    print("End")
    print(count)
    print("Iteracions fil 1 a bucle d'espera %s" %contador1)
    print("Iteracions fil 2 a bucle d'espera %s" %contador2)
    #amb aquets darrers prints mostram que el fil 1 esta molt mes temps esperant, degut a l'sleep

if __name__ == "__main__":
    start_time = time.time()
    main()
