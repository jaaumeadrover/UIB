import threading
import time

THREADS = 2
MAX = 1000000
count = 0
wantp = False
wantq = False

def thread1(): 
    global wantq
    global wantp
    global count
    #bucle principal
    for i in range(MAX):
       #solicitam entrar
        wantp = True
        #espera activa
        while  wantq:
            pass
        #regio critica
        count += 1
        wantp = False
    print("Hi, I'm the thread {}".format(threading.current_thread().name) +
          "and i have finished \n" )
    
    
    
def thread2():
    global wantp
    global wantq
    global count   
    #bucle principal
    for i in range(MAX):
        #solicitam entrar
        wantq = True
        #espera acitva
        while  wantp:
            pass
        #regio critica
        count += 1
        wantq = False
    print("Hi, I'm the thread {}".format(threading.current_thread().name) +
          "and i have finished \n" )
    
    
def main():
    threads = []

   
    # Create new threads
    t = threading.Thread(target=thread1)
    threads.append(t)
    t.start() # start the thread
    t = threading.Thread(target=thread2)
    threads.append(t)
    t.start() # start the thread
    

    # Wait for all threads to complete
    for t in threads:
        t.join()
    print("--- %s seconds ---" % (time.time() - start_time))
    print("End")
    print(count)

if __name__ == "__main__":
    start_time = time.time()
    main()
