import threading
import time

THREADS = 2
MAX = 100
count = 0
wantp = False
wantq = False

def thread1():
    global count
    global wantq
    global wantp
    #bucle principal
    for i in range(MAX):
        #espera activa
        while  wantq:
            pass
        #entram regio critica
        wantp = True
        count += 1
        wantp = False
    print("Hi, I'm the thread {}".format(threading.current_thread().name) +
          "and i have finished \n" )
    
    
    
def thread2():
    global count
    global wantp
    global wantq
    #bucle principal
    for i in range(MAX):
        #espera activa
        while  wantp:
            pass
        #entram regio critica
        wantq = True
        count += 1
        wantq = False
    print("Hi, I'm the thread {}".format(threading.current_thread().name) +
          "and i have finished \n" )
    
    
def main():
    threads = []

   
    # Create new threads
    t = threading.Thread(target=thread1)
    threads.append(t)
    t.start() # start the thread
    t = threading.Thread(target=thread2)
    threads.append(t)
    t.start() # start the thread
    

    # Wait for all threads to complete
    for t in threads:
        t.join()
    print("--- %s seconds ---" % (time.time() - start_time))
    print("End")
    print(count)

if __name__ == "__main__":
    start_time = time.time()
    main()
