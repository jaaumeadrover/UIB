#!/usr/bin/env python

"""
Dekker's first attempt.

Created by: Jose David Pérez Cañellas.

Start 2 threads: 'p' and 'q'.

'p' will break before setting 'turn' to 2 (p4), 'q' will be locked at q2
"""

import threading

turn = 1

def p():
    global turn
    print('Hello from {} thread'.format(threading.current_thread().name))

    while True:
        # p1: non-critical section
        break  # exit while True loop
        # p2: await turn = 1
        print('Thread {} await'.format(threading.current_thread().name))
        while turn != 1: pass
        # p3: critical section
        print('Thread {} critical section'.format(threading.current_thread().name))
        # p4: turn <-- 2
        turn = 2

    print('Thread {}: Bye!'.format(threading.current_thread().name))


def q():
    global turn
    print('Hello from {} thread'.format(threading.current_thread().name))

    while True:
        # q1: non-critical section
        pass
        # q2: await turn = 2
        print('Thread {} await'.format(threading.current_thread().name))
        while turn != 2: pass
        # q3: critical section
        print('Thread {} critical section'.format(threading.current_thread().name))
        # q4: turn <-- 1
        turn = 1


def main():
    threads = []

    thread_p = threading.Thread(target=p, name='p')
    threads.append(thread_p)
    thread_p.start()

    thread_q = threading.Thread(target=q, name='q')
    threads.append(thread_q)
    thread_q.start()

    for t in threads:
        t.join()


if __name__ == '__main__':
    main()