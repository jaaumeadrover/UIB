#!/usr/bin/env python

"""
Dekker's fourth attempt.

Created by: Jose David Pérez Cañellas.

Start 2 threads: 'p' and 'q'.

Set the state wantx before the while wantx loop.
Ensures mutual exclusion but may produce livelock at x3-x5 steps.
Add some sleeps to see livelock and critical section access.
"""

from random import random
import threading
from time import sleep


wantp, wantq = False, False


def p():
    global wantp, wantq
    print('Hello from {} thread'.format(threading.current_thread().name))

    while True:
        # p1: non-critical section
        pass
        # p2: wantp <-- true
        wantp = True
        sleep(random())
        # p3: await wantq = false
        while wantq:
            print('Thread {} livelock'.format(threading.current_thread().name))
            wantp = False
            sleep(random())
            wantp = True
            sleep(random())
        # p4: critical section
        print('Thread {} critical section'.format(threading.current_thread().name))
        # p5: wantp <-- false
        wantp = False


def q():
    global wantp, wantq
    print('Hello from {} thread'.format(threading.current_thread().name))

    while True:
        # q1: non-critical section
        pass
        # q2: wantq <-- true
        wantq = True
        sleep(random())
        # q3: await wantp = false
        while wantp:
            print('Thread {} livelock'.format(threading.current_thread().name))
            wantq = False
            sleep(random())
            wantq = True
            sleep(random())
        # q4: critical section
        print('Thread {} critical section'.format(threading.current_thread().name))
        # q5: wantq <-- false
        wantq = False


def main():
    threads = []

    thread_p = threading.Thread(target=p, name='p')
    threads.append(thread_p)
    thread_p.start()

    thread_q = threading.Thread(target=q, name='q')
    threads.append(thread_q)
    thread_q.start()

    for t in threads:
        t.join()


if __name__ == '__main__':
    main()