#!/usr/bin/env python

"""
Dekker's second attempt.

Created by: Jose David Pérez Cañellas.

Start 2 threads: 'p' and 'q'.

Add some sleep before setting wantx to true and check if wantp and wantq are true
inside the critical section.
"""

import threading
from time import sleep


wantp, wantq = False, False


def p():
    global wantp, wantq
    print('Hello from {} thread'.format(threading.current_thread().name))

    while True:
        # p1: non-critical section
        pass
        # p2: await wantq = false
        while wantq: pass
        # p3: wantp <-- true
        sleep(1)  # add some time to force CS error
        wantp = True
        # p4: critical section
        if wantp and wantq:
            print('Thread {} CS ERROR'.format(threading.current_thread().name))
            while True: pass

        print('Thread {} critical section'.format(threading.current_thread().name))
        # p5: wantp <-- false
        wantp = False


def q():
    global wantp, wantq
    print('Hello from {} thread'.format(threading.current_thread().name))

    while True:
        # q1: non-critical section
        pass
        # q2: await wantp = false
        while wantp: pass
        # q3: wantq <-- true
        sleep(1)  # add some time to force CS error
        wantq = True
        # q4: critical section
        if wantp and wantq:
            print('Thread {} CS ERROR'.format(threading.current_thread().name))
            while True: pass

        print('Thread {} critical section'.format(threading.current_thread().name))
        # q5: wantq <-- false
        wantq = False


def main():
    threads = []

    thread_p = threading.Thread(target=p, name='p')
    threads.append(thread_p)
    thread_p.start()

    thread_q = threading.Thread(target=q, name='q')
    threads.append(thread_q)
    thread_q.start()

    for t in threads:
        t.join()


if __name__ == '__main__':
    main()