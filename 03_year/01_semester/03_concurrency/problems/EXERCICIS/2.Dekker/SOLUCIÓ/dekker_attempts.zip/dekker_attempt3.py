#!/usr/bin/env python

"""
Dekker's third attempt.

Created by: Jose David Pérez Cañellas.

Start 2 threads: 'p' and 'q'.

Set the state wantx before the await statement.
Now await is part of the critical section, but may produce deadlock situations.
"""

import threading


wantp, wantq = False, False


def p():
    global wantp, wantq
    print('Hello from {} thread'.format(threading.current_thread().name))

    while True:
        # p1: non-critical section
        pass
        # p2: wantp <-- true
        wantp = True
        # p3: await wantq = false
        print('Thread {} await'.format(threading.current_thread().name))
        while wantq: pass
        # p4: critical section
        print('Thread {} critical section'.format(threading.current_thread().name))
        # p5: wantp <-- false
        wantp = False


def q():
    global wantp, wantq
    print('Hello from {} thread'.format(threading.current_thread().name))

    while True:
        # q1: non-critical section
        pass
        # q2: wantq <-- true
        wantq = True
        # q3: await wantp = false
        print('Thread {} await'.format(threading.current_thread().name))
        while wantp: pass
        # q4: critical section
        print('Thread {} critical section'.format(threading.current_thread().name))
        # q5: wantq <-- false
        wantq = False


def main():
    threads = []

    thread_p = threading.Thread(target=p, name='p')
    threads.append(thread_p)
    thread_p.start()

    thread_q = threading.Thread(target=q, name='q')
    threads.append(thread_q)
    thread_q.start()

    for t in threads:
        t.join()


if __name__ == '__main__':
    main()