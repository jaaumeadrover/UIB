#!/usr/bin/env python

"""
Manna-Pnueli algorithm (CS error).

Created by: Jose David Pérez Cañellas.

Start 2 threads: 'p' and 'q'.

Does not satisfy mutual exclusion.

Step by step code execution:

Initial state -> q1 -> q3 -> q4

wantp = 0, wantq = -1

q4: await wantp != -wantq, await 0 != 1, ready to execute CS and q5

-> p1

p1: if wantq = -1, ready to execute p2

-> q CS -> q5 (exit CS)

q process end first loop iteration

wantp = 0, wantq = 0

-> q1

q1: if wantp = -1, ready to execute q3

-> p2

wantp = -1, wantq = 0

-> p4

p4: await wantq != wantp, await -1 != 0, ready to execute q CS and p5

-> p CS !!!

wantp = -1, wantq = 0

At this point if p doesn't exit the CS, will be critical section error.
Because of the current wantp value and next q statement (assign wantq to -1),
q await condition (wantp != -wantq) will let q pass to the critical section.

-> q3

wantp = -1, wantq = -1

-> q4

q4: await wantp != -wantq, await -1 != 1, ready to execute q CS and q5

-> q CS

!!! Game over !!!
"""

import threading
from time import sleep

wantp, wantq = 0, 0


def p():
    global wantp, wantq
    name = threading.current_thread().name
    print('Hello from {} thread'.format(name))

    while True:
        # non-critical section
        pass

        sleep(3)
        print('p1: if wantq = -1')
        if wantq == -1:  # p1: if wantq = -1
            sleep(6)
            print('p2: wantp <-- -1')
            wantp = -1   # p2: wantp <-- -1
        else:
            print('p3: wantp <-- 1')
            wantp = 1    # p3: wantp <-- 1

        print('p4: await wantq != wantp')
        while wantq == wantp: pass  # p4: await wantq != wantp

        # critical section
        print('p critical section')
        while True: pass

        print('p5: wantp <-- 0')
        wantp = 0  # p5: wantp <-- 0


def q():
    global wantp, wantq
    name = threading.current_thread().name
    print('Hello from {} thread'.format(threading.current_thread().name))

    while True:
        # non-critical section

        print('q1: if wantp = -1')
        if wantp == -1:  # q1: if wantp = -1
            print('q2: wantq <-- 1')
            wantq = 1    # q2: wantq <-- 1
        else:
            print('q3: wantq <-- -1')
            wantq = -1   # q3: wantq <-- -1

        print('q4: await wantp != -wantq')        
        while wantp == -wantq: pass  # q4: await wantp != -wantq

        # critical section
        sleep(6)
        print('q critical section')

        print('q5: wantq <-- 0')
        wantq = 0  # q5: wantq <-- 0

        #####################################################
        ## Duplicated code !!!                             ##
        ## This way is easy to put the sleeps on each step ##
        ## And it's easy to visualize the error            ##
        #####################################################

        # non-critical section
        
        print('q1: if wantp = -1')
        if wantp == -1:  # q1: wantp = -1
            print('q2: wantq <-- 1')
            wantq = 1    # q2: wantq <-- 1
        else:
            sleep(6)
            print('q3: wantq <-- -1')
            wantq = -1   # q3: wantq <-- -1

        print('q4: await wantp != -wantq')        
        while wantp == -wantq: pass  # q4: await wantp != -wantq

        # critical section
        print('q critical section')
        while True: pass

        print('q5: wantq <-- 0')
        wantq = 0  # q5: wantq <-- 0


def main():
    threads = []

    thread_p = threading.Thread(target=p, name='p')
    threads.append(thread_p)
    thread_p.start()

    thread_q = threading.Thread(target=q, name='q')
    threads.append(thread_q)
    thread_q.start()

    for t in threads:
        t.join()


if __name__ == '__main__':
    main()