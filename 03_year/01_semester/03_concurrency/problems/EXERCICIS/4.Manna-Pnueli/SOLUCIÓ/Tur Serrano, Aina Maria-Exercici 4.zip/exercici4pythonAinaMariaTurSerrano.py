import threading
import time
THREADS=2
MAX_COUNT=100000
wantp=0
wantq=0
n=0

def thread_p():
    global n,wantp,wantq
    for i in range(MAX_COUNT//2):
        
        if(wantq==-1):
            wantp=-1
        else:
            wantp=1
        while(wantq==wantp):
            pass
        n+=1
        wantp=0


def thread_q():
    global n,wantp,wantq
    for i in range(MAX_COUNT//2):
        
        if(wantp==-1):
            wantq=1
        else:
            wantq=-1
        while(wantp ==-wantq):
            pass
        n+=1
        wantq=0
  


def main():
    pthread = threading.Thread(target=thread_p)
    qthread = threading.Thread(target=thread_q)

    pthread.start()
    qthread.start()
    pthread.join()
    qthread.join()

    print("Counter value: {} Expected: {}\n".format(n, MAX_COUNT))
    error = (MAX_COUNT - n) //MAX_COUNT * 100
    print("Counter value: {} Expected: {} Error: {}\n".format(n, MAX_COUNT, error))


if __name__ == "__main__":
    main()   
