public class Main implements Runnable {

    private static final int MAX_COUNT = 100000;
    private static final int THREADS = 4;

    private enum pstate {IDLE, WAITING, ACTIVE};
    private static pstate flags[];
    private static int turn;
    private int id;

    private static int n;

    public Main(int id){
        this.id = id;
    }

    @Override
    public void run() {
        System.out.println("Hola soy " + id);
        int index = 0;
        for(int i = 0; i<(MAX_COUNT/THREADS);i++) {
            System.out.println("Id Iniciado: " + id + " indice "+ i);
            while ((index < THREADS) || ((turn != id) && (flags[turn] != pstate.IDLE))) {
                flags[id] = pstate.WAITING;

                index = turn;
                while (index != id) {
                    if (flags[index] != pstate.IDLE) {
                        index = turn;
                    } else {
                        index = (index + 1) % THREADS;
                    }
                }

                flags[id] = pstate.ACTIVE;

                index = 0;

                while ((index < THREADS) && ((index == id) || (flags[index] != pstate.ACTIVE))) {
                    index++;
                }
            }

            //Sección crítica
            turn = id;
            n += 1;
            //System.out.println("Soy " + id + " he incrementado n ahora vale " + n);
            //Finalizamos la sección crítica
            index = (turn + 1) % THREADS;
            while (flags[index] == pstate.IDLE) {
                index = (index + 1) % THREADS;
            }
            turn = index;
            flags[id] = pstate.IDLE;
            //Fin
        }
        System.out.println("Id terminado: " + id);
    }

    public static void main(String[] args) throws InterruptedException {
        Thread[] threads = new Thread[THREADS];
        flags = new pstate[THREADS];
        turn = 0; n=0;
        for(int i = 0; i<THREADS;i++){
            flags[i] = pstate.IDLE;
            threads[i] = new Thread(new Main(i));
            threads[i].start();
        }
        for (int i = 0; i < THREADS; i++){
            threads[i].join();
        }
        float error =  ((float) (MAX_COUNT-n)/MAX_COUNT)*100;
        System.out.println("Valor obtenido:" + n + " Valor Esperado:" + MAX_COUNT + " Error Producido: " + error);
    }
}