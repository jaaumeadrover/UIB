package doranthomas;

/**
 *
 * @author Juan Mesquida Arenas i Jogil Moreno Martínez
 */
public class DoranThomas implements Runnable {

    static final int THREADS = 2;
    static final int MAX_COUNT = 100000;
    static volatile int want[] = new int[THREADS];
    static volatile int torn = 0;
    static volatile int n = 0;
    int id;

    /**
     * MÉTODE CONSTRUCTOR
     *
     * @param id identificador proces
     */
    public DoranThomas(int id) {
        this.id = id;
    }

    /**
     * MÉTODE CONSTRUCTOR
     *
     * @param args
     * @throws InterruptedException
     */
    public static void main(String[] args) throws InterruptedException {
        Thread[] threads = new Thread[THREADS];
        want[0] = 0; //WANTP
        want[1] = 0; //WANTQ

        //llançam fils
        for (int i = 0; i < THREADS; i++) {
            threads[i] = new Thread(new DoranThomas(i));
            threads[i].start();
        }
        //esperam a que acabin els fils
        for (int i = 0; i < THREADS; i++) {
            threads[i].join();
        }
        float error = (MAX_COUNT - n) / (float) MAX_COUNT * 100;
        System.out.printf("Counter value: %d Expected: %d Error: %3.6f%%\n", n, MAX_COUNT, error);
    }

    /**
     * FIL LLANÇAT
     */
    @Override
    public void run() {
        int max = MAX_COUNT / THREADS;
        int altreProces = (id + 1) % THREADS;

        for (int i = 0; i < max; i++) {

            want[id] = 1;
            if (want[altreProces] == 1) {
                if (torn == altreProces) {
                    want[id] = 0;
                    //espera
                    while (torn == altreProces) {}
                    want[id] = 1;
                }
                //espera
                while (want[altreProces] == 1) {}

            }
            //SC
            n += 1;
            System.out.println("procés: " + id);
            //Sortim de la SC
            want[id] = 0;
            torn = altreProces;
        }
    }

}
